package com.example.carscanner

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
        if (Build.VERSION.SDK_INT >= 31) perm.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT))
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF3DDC97))) {
                Surface(Modifier.fillMaxSize()) { App { adapter?.bondedDevices?.toList() ?: emptyList() } }
            }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun App(devices: () -> List<BluetoothDevice>) {
    val elm = remember { Elm327() }
    val scope = rememberCoroutineScope()
    var connected by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Pilih adapter OBD yang sudah di-pair") }
    var tab by remember { mutableIntStateOf(0) }
    val values = remember { mutableStateMapOf<String, Double>() }
    var dtcs by remember { mutableStateOf<List<String>?>(null) }
    var supported by remember { mutableStateOf<Set<String>>(emptySet()) }
    val shown = if (supported.isEmpty()) PIDS else PIDS.filter { it.code in supported }
    var vin by remember { mutableStateOf("-") }

    LaunchedEffect(connected, tab) {
        while (connected && tab == 0) {
            for (p in shown) { runCatching { elm.query(p) }.getOrNull()?.let { values[p.code] = it } }
            delay(100)
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
        Text("Car Scanner Pro", fontSize = 24.sp, style = MaterialTheme.typography.headlineSmall)
        Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        if (!connected) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(devices()) { d ->
                    OutlinedButton({
                        status = "Menghubungkan ke ${d.name}…"
                        scope.launch {
                            runCatching { elm.connect(d) }
                                .onSuccess {
                                    status = "Mendeteksi protokol, tunggu hingga 15 detik…"
                                    val (pr, sup) = runCatching { elm.detect() }.getOrDefault("?" to emptySet())
                                    supported = sup; connected = true
                                    status = "Terhubung: ${d.name} · $pr · ${sup.size} PID didukung"
                                    vin = runCatching { elm.vin() }.getOrDefault("-") }
                                .onFailure { status = "Gagal: ${it.message}. Pastikan kontak mobil ON." }
                        }
                    }, Modifier.fillMaxWidth()) { Text(d.name ?: d.address) }
                }
            }
        } else {
            TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("Live data") })
                Tab(tab == 1, { tab = 1 }, text = { Text("Kode error") })
            }
            Spacer(Modifier.height(12.dp))
            if (tab == 0) {
                LazyVerticalGrid(GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(shown) { p ->
                        val v = values[p.code]
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(p.name, style = MaterialTheme.typography.labelLarge)
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(8.dp)) {
                                    CircularProgressIndicator(progress = { ((v ?: 0.0) / p.max).coerceIn(0.0, 1.0).toFloat() }, modifier = Modifier.size(84.dp), strokeWidth = 8.dp)
                                    Text(v?.let { if (it >= 100) "%.0f".format(it) else "%.1f".format(it) } ?: "–", fontSize = 20.sp)
                                }
                                Text(p.unit)
                            }
                        }
                    }
                }
            } else {
                Text("VIN: $vin")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ scope.launch { dtcs = elm.readDtc() } }) { Text("Baca kode error") }
                    OutlinedButton({ scope.launch { status = if (elm.clearDtc()) "Kode error dihapus" else "Gagal menghapus"; dtcs = null } }) { Text("Hapus kode error") }
                }
                dtcs?.let { list ->
                    if (list.isEmpty()) Text("Tidak ada kode error tersimpan.", Modifier.padding(top = 12.dp))
                    else list.forEach { Text(it, fontSize = 22.sp, modifier = Modifier.padding(top = 8.dp)) }
                }
            }
            Spacer(Modifier.weight(1f))
            TextButton({ elm.close(); connected = false; status = "Terputus" }) { Text("Putuskan koneksi") }
        }
    }
}
