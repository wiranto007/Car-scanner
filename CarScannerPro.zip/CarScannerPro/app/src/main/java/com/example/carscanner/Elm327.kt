package com.example.carscanner

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

data class Pid(val code: String, val name: String, val unit: String, val max: Double, val calc: (IntArray) -> Double)

val PIDS = listOf(
    Pid("0C", "RPM", "rpm", 8000.0) { (it[0] * 256 + it[1]) / 4.0 },
    Pid("0D", "Kecepatan", "km/h", 240.0) { it[0].toDouble() },
    Pid("05", "Suhu coolant", "°C", 130.0) { it[0] - 40.0 },
    Pid("04", "Beban mesin", "%", 100.0) { it[0] * 100 / 255.0 },
    Pid("11", "Throttle", "%", 100.0) { it[0] * 100 / 255.0 },
    Pid("0F", "Suhu intake", "°C", 100.0) { it[0] - 40.0 },
    Pid("0B", "Tekanan MAP", "kPa", 255.0) { it[0].toDouble() },
    Pid("10", "MAF", "g/s", 300.0) { (it[0] * 256 + it[1]) / 100.0 },
    Pid("42", "Tegangan ECU", "V", 16.0) { (it[0] * 256 + it[1]) / 1000.0 },
    Pid("2F", "Level BBM", "%", 100.0) { it[0] * 100 / 255.0 },
    Pid("5C", "Suhu oli", "°C", 150.0) { it[0] - 40.0 },
)

class Elm327 {
    private var socket: BluetoothSocket? = null
    private var inp: InputStream? = null
    private var out: OutputStream? = null

    @SuppressLint("MissingPermission")
    suspend fun connect(dev: BluetoothDevice) = withContext(Dispatchers.IO) {
        close()
        val s = dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
        s.connect()
        socket = s; inp = s.inputStream; out = s.outputStream
        for (c in listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATAT1", "ATSP0")) send(c, 4000)
    }

    /** Memicu deteksi protokol (ISO 9141/KWP bisa 5-10 dtk), lalu daftar PID yang didukung ECU. */
    suspend fun detect(): Pair<String, Set<String>> = withContext(Dispatchers.IO) {
        val set = mutableSetOf<String>()
        var base = 0
        while (base <= 0x40) {
            val code = "%02X".format(base)
            val hex = send("01$code", if (base == 0) 15000 else 5000).replace(Regex("\\s"), "").uppercase()
            val idx = hex.indexOf("41$code")
            if (idx < 0) break
            val b = hex.substring(idx + 4).chunked(2).mapNotNull { it.toIntOrNull(16) }.take(4)
            if (b.size < 4) break
            val mask = b.fold(0L) { a, x -> a * 256 + x }
            for (i in 0 until 32) if (mask and (1L shl (31 - i)) != 0L) set += "%02X".format(base + i + 1)
            if ("%02X".format(base + 0x20) !in set) break
            base += 0x20
        }
        send("ATDP") to set
    }

    fun close() { runCatching { socket?.close() }; socket = null }

    @Synchronized
    private fun send(cmd: String, timeout: Long = 4000): String {
        val o = out ?: error("Belum terhubung"); val i = inp ?: error("Belum terhubung")
        while (i.available() > 0) i.read()
        o.write("$cmd\r".toByteArray()); o.flush()
        val sb = StringBuilder(); val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            if (i.available() > 0) { val c = i.read().toChar(); if (c == '>') break; sb.append(c) } else Thread.sleep(5)
        }
        return sb.toString().replace("SEARCHING...", "").trim()
    }

    suspend fun query(pid: Pid): Double? = withContext(Dispatchers.IO) {
        val hex = send("01${pid.code}").replace(Regex("\\s"), "").uppercase()
        val idx = hex.indexOf("41${pid.code}")
        if (idx < 0) return@withContext null
        val data = hex.substring(idx + 4).chunked(2).filter { it.length == 2 }.mapNotNull { it.toIntOrNull(16) }
        if (data.isEmpty()) null else runCatching { pid.calc((data + 0).toIntArray()) }.getOrNull()
    }

    suspend fun readDtc(): List<String> = withContext(Dispatchers.IO) {
        val res = mutableListOf<String>()
        send("03").lines().map { it.replace(" ", "").uppercase() }.filter { it.startsWith("43") }.forEach { line ->
            var b = line.drop(2).chunked(2).mapNotNull { it.toIntOrNull(16) }
            if (b.size % 2 == 1) b = b.drop(1) // byte jumlah DTC (CAN)
            b.chunked(2).filter { it.size == 2 && (it[0] != 0 || it[1] != 0) }.forEach {
                val t = "PCBU"[it[0] shr 6]
                res += "$t${(it[0] shr 4) and 3}${(it[0] and 15).toString(16)}${"%02X".format(it[1])}".uppercase()
            }
        }
        res
    }

    suspend fun clearDtc(): Boolean = withContext(Dispatchers.IO) { send("04").contains("44") }

    suspend fun vin(): String = withContext(Dispatchers.IO) {
        val r = send("0902").lines().joinToString("") { it.replace(" ", "").replace(Regex("^\\d:"), "") }
        val h = r.chunked(2).mapNotNull { it.toIntOrNull(16) }.filter { it in 48..90 }
        h.map { it.toChar() }.joinToString("").takeLast(17).ifEmpty { "-" }
    }
}
